#!/bin/bash

i=1


while [ $i -lt "13" ]
do
  touch "DATA$i.dat"
  tail -n +4 $"file$i.dat" > "DATA$i.dat"
  i=$(($i+1))
done
