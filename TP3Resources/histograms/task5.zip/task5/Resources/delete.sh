#!/bin/bash

i=1

while [ $i -lt "13" ]
do
  rm "file$i.dat"
  i=$(($i+1))
done
