#!/bin/bash


i=1
IFS=$'\n'




while [ $i -lt "13" ]
do
  found=0
  count=0
  touch "file$i.dat"
  for line in `cat histo_$i`
  do


    if [ $line == " #         105 : dS/dmZZ (fb/GeV)" ];
    then
        found=1
    fi
    
    if [ $line == "e" ]
    then
        found=0
    fi

    if [ $found -eq 1 ];
    then
       echo $line >> $"file$i.dat"
    fi 

    count=$(($count+1))
  done
  i=$(($i+1))
done


